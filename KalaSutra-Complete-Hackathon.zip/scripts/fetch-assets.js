const https = require('https');
const fs = require('fs');
const path = require('path');

const OWNER = 'hpaliwal7983-crypto';
const REPO = 'kalasutra';
const REF = '37a25f30436694398cacf8ae1d204eb651e80b4d';
const API_ROOT = `https://api.github.com/repos/${OWNER}/${REPO}/contents/public/assets?ref=${REF}`;
const RAW_ROOT = `https://raw.githubusercontent.com/${OWNER}/${REPO}/${REF}/public/assets/`;
const DEST_ROOT = path.join(__dirname, '..', 'public', 'assets');

function get(url, binary=false){
  return new Promise((resolve,reject)=>{
    https.get(url,{headers:{'User-Agent':'KalaSutra-asset-fetcher','Accept':binary?'application/octet-stream':'application/vnd.github+json'}},res=>{
      if(res.statusCode>=300&&res.statusCode<400&&res.headers.location)return get(res.headers.location,binary).then(resolve,reject);
      if(res.statusCode!==200){let b='';res.on('data',c=>b+=c);res.on('end',()=>reject(new Error(`HTTP ${res.statusCode} for ${url}: ${b.slice(0,200)}`)));return;}
      const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>resolve(Buffer.concat(chunks)));
    }).on('error',reject);
  });
}
async function list(url){return JSON.parse((await get(url)).toString('utf8'));}
async function walk(apiUrl, rel=''){
  const entries=await list(apiUrl);
  for(const e of entries){
    const nextRel=rel?path.posix.join(rel,e.name):e.name;
    if(e.type==='dir') await walk(e.url,nextRel);
    else if(e.type==='file'){
      const dest=path.join(DEST_ROOT,...nextRel.split('/'));
      fs.mkdirSync(path.dirname(dest),{recursive:true});
      if(fs.existsSync(dest) && fs.statSync(dest).size===e.size){console.log(`✓ ${nextRel}`);continue;}
      const data=await get(RAW_ROOT+nextRel.split('/').map(encodeURIComponent).join('/'),true);
      fs.writeFileSync(dest,data);
      console.log(`↓ ${nextRel} (${data.length} bytes)`);
    }
  }
}
(async()=>{
  try{fs.mkdirSync(DEST_ROOT,{recursive:true}); await walk(API_ROOT); console.log('KalaSutra original assets ready.');}
  catch(e){console.error('Asset fetch failed:',e.message); process.exit(1);}
})();
