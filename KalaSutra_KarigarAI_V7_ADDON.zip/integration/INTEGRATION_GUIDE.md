# KalaSutra Karigar AI V7 add-on

This adds the first artisan voice flow to existing V6. V6 router/screens, Add Product, camera and verification remain authoritative. The centered avatar is transparent and click-through so V6 controls remain usable.

## Contents

- `karigar-ai/karigar-warm-welcome-v7.js` — warm avatar, Realtime voice, timeout/error handling, fallback, navigation and Add Product actions.
- `karigar-ai/karigar-warm-welcome-v7.css` — transparent click-through styling, with a smaller avatar when voice is unavailable.
- `integration/v6-integration.patch` — focused changes to V6 `app.js`, `index.html`, and `server/ai-routes.js`.
- This guide.

## Integrate

1. Keep a backup of V6; do not replace the project with this ZIP.
2. Copy the two `karigar-ai/` files to the project root.
3. Apply the patch against the matching V6 base. Review conflicts; do not replace whole files.
4. In Render, open the `kalasutra` Web Service → Environment and set `OPENAI_API_KEY` to the secret value. Choose **Save, rebuild, and deploy** or **Save and deploy**, not Save only. Never put the key in browser code, Git, or this ZIP.
5. OpenAI API access also needs available API billing credits. A valid key with an exhausted balance returns `credit_balance_exhausted`; add credits in OpenAI Platform billing before retrying.
6. Sign in as an artisan over HTTPS. The welcome/avatar appears over V6; only copilot controls catch taps. Tap **Start Talking** to unlock mic/audio.
7. Say “Mera naya product add karna hai.” Check the existing Add Product form, photo/making-proof controls, voice edits, review and spoken confirmation before submission.
8. Check language selection and that Buyer screens remain usable.

## Safety

- OpenAI key is server-only.
- No automatic product submission. Spoken confirmation is required in the following turn and expires after two minutes.
- Product facts come only from the artisan; missing required details are requested.
- On Realtime failure, supported browsers use audio capture, OpenAI transcription, the AI response endpoint and OpenAI TTS. Browser speech APIs are last resort.
- OpenAI billing/quota errors are converted to a short readable message instead of raw provider JSON.

## Checks performed

- Node syntax checks passed for app, copilot, AI routes and server; `git diff --check` passed.
- Local HTTP smoke returned 200 for app, copilot, CSS and avatar; empty AI inputs returned expected 400 validation responses.
- A mocked exhausted-credit response returned a readable message and `credit_balance_exhausted` code.
- Full live voice, device microphone, iOS Safari and camera-to-verification need testing on a signed-in device with API credits available.

The ZIP excludes the full V6 project, database, unrelated assets and secrets.
