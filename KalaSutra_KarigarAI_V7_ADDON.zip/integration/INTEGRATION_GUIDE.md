# KalaSutra Karigar AI V7 add-on

This add-on attaches the first voice-first artisan flow to KalaSutra V6. The existing V6 router, screens, Add Product, media controls, verification, Buyer experience and assets remain the source of truth.

## Contents

- `karigar-ai/karigar-warm-welcome-v7.js` — centered avatar, OpenAI Realtime, timeout/error handling, voice fallback and existing-screen actions.
- `karigar-ai/karigar-warm-welcome-v7.css` — transparent click-through companion styling.
- `integration/v6-integration.patch` — focused V6 integration edits to `app.js`, `index.html`, and `server/ai-routes.js`.
- This guide.

## Integrate/deploy

1. Keep a backup of the existing V6 checkout; do not replace it with this ZIP.
2. Copy the two files in `karigar-ai/` into the project root.
3. Apply the patch to the matching V6 base, reviewing conflicts rather than replacing entire files.
4. In the **Render Web Service named `kalasutra`**, open **Environment** and ensure there is a non-empty variable named exactly `OPENAI_API_KEY` with the secret value. Do not put it in frontend code, Git, or this ZIP. If the app displays “AI voice needs OPENAI_API_KEY in the server environment,” the running Node process cannot read that variable. Check the service/variable name and save the environment change so Render restarts/redeploys.
5. Optional model overrides: `KALASUTRA_REALTIME_MODEL`, `KALASUTRA_AI_MODEL`, `KALASUTRA_TRANSCRIBE_MODEL`, and `KALASUTRA_TTS_MODEL`.
6. Sign in as an artisan over HTTPS. Warm welcome/avatar shows on top of the app; only its own controls catch taps, so the V6 app stays usable behind it. Tap **Start Talking** to unlock audio and microphone.
7. Say “Mera naya product add karna hai.” Confirm Add Product opens, the copilot remains available, stated details update the existing form, existing photo/making-proof controls work, and the voice summary asks before verification submission.
8. Verify the language selector and Buyer screens remain usable.

## Safety

- The OpenAI key is read by the server only.
- V6 screens and verification remain authoritative.
- No product is submitted automatically. The copilot must speak a confirmation request and receive a clear yes in the following turn; permission expires after two minutes and resets when leaving Add Product.
- Product facts must come from the artisan. Missing required photo/story/price/making proof are requested.
- If Realtime is unavailable, supported browsers use audio capture, OpenAI transcription, the AI response endpoint and OpenAI TTS. Browser speech APIs are a last resort.

## Verification performed

- `node --check` passed for `app.js`, `karigar-warm-welcome-v7.js`, `server/ai-routes.js`, and `server/server.js`.
- `git diff --check` passed.
- Local HTTP smoke: `/`, app script, copilot script and avatar returned 200; empty transcription/product-assist payloads returned expected 400 validation responses.
- Live OpenAI voice, microphone permission, iOS Safari and the complete camera-to-verification path require testing on a signed-in device after the server key is configured.

The ZIP excludes the full V6 project, database, unrelated assets, and secrets.
