# KalaSutra Karigar AI V7 add-on

This package adds the first V7 voice-first artisan flow to the existing KalaSutra V6 app. V6 remains the source of truth: the existing router, Add Product screen, camera/proof controls, verification, Buyer UI and assets are retained.

## Package contents

- `karigar-ai/karigar-warm-welcome-v7.js` — centered welcome/avatar, OpenAI Realtime voice path, timeout/error handling, fallback, role-aware navigation and voice-driven Add Product actions.
- `karigar-ai/karigar-warm-welcome-v7.css` — add-on presentation styles.
- `integration/v6-integration.patch` — focused changes to V6 `app.js`, `index.html`, and `server/ai-routes.js`. Apply against the matching V6 base; review conflicts rather than replacing whole files.
- This guide.

## Integrate

1. Keep a backup/commit of the V6 checkout. Do not replace the project with this ZIP.
2. Copy the two files in `karigar-ai/` to the V6 project root.
3. Apply `integration/v6-integration.patch` against the matching V6 base. It wires the existing Add Product form and verification action, mounts for artisans, updates script cache versions, and adds server-side OpenAI endpoints.
4. Set `OPENAI_API_KEY` in the Render server environment. Never put the key in browser code, the ZIP, or Git. Optional overrides: `KALASUTRA_REALTIME_MODEL`, `KALASUTRA_AI_MODEL`, `KALASUTRA_TRANSCRIBE_MODEL`, and `KALASUTRA_TTS_MODEL`.
5. Deploy the existing V6 service and wait for it to restart.
6. Open the HTTPS site as an artisan and tap **Start Talking**. The warm welcome is visible immediately; audio and mic start only after this tap, avoiding browser autoplay blocks.
7. Say “Mera naya product add karna hai.” Check that Add Product opens and the compact copilot stays available. Speak product details, use existing photo and making-proof controls, review the current draft, and confirm aloud before submission for verification.
8. Check the language selector and confirm the Buyer experience remains unchanged.

## Safety

- OpenAI key is read on the server only.
- The existing Add Product and verification routes remain authoritative.
- The copilot never auto-submits. It must speak a confirmation request first and receive a clear confirmation in the next turn. That permission expires in two minutes and resets when leaving Add Product.
- Product details are grounded in the artisan's words; missing photo/story/price/making proof are requested.
- If Realtime fails, supported browsers use audio capture, OpenAI transcription, the AI response endpoint and OpenAI TTS. Browser speech recognition/synthesis are last-resort fallbacks.

## Checks performed

- `node --check` passed for `app.js`, `karigar-warm-welcome-v7.js`, `server/ai-routes.js`, and `server/server.js`.
- `git diff --check` passed.
- Local HTTP smoke: `/` and the copilot script returned 200; invalid empty transcription and product-assist inputs returned expected 400 validation responses.
- The live OpenAI conversation, mic permission, spoken output, iOS Safari, and full camera-to-verification flow were not exercised. Test those on a signed-in device after deployment before accepting the voice flow as complete.

The ZIP excludes the full V6 project, database, unrelated assets, and secrets.
