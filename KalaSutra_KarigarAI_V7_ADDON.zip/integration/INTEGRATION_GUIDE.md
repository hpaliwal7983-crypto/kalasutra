# KalaSutra Karigar AI V7 add-on

This package adds the first V7 voice-first artisan flow to the existing KalaSutra V6 app. V6 remains the source of truth: the existing router, Add Product screen, camera/proof controls, verification, Buyer UI and assets are retained.

## What is included

- `karigar-ai/karigar-warm-welcome-v7.js` — centered welcome/avatar, OpenAI Realtime voice path, timeouts and state-aware fallback, role-aware navigation, and voice-driven Add Product actions.
- `karigar-ai/karigar-warm-welcome-v7.css` — add-on presentation styles.
- `integration/v6-integration.patch` — focused changes to the existing V6 `app.js`, `index.html`, and `server/ai-routes.js`. Apply against the matching V6 checkout; review conflicts rather than replacing whole files.
- This guide.

## Integrate

1. Keep a backup/commit of your existing V6 checkout. Do not replace the project with this ZIP.
2. Copy the two files in `karigar-ai/` to the V6 project root so the existing server can serve them.
3. Apply `integration/v6-integration.patch` to the matching V6 checkout. It wires the existing Add Product form state and submit/verification action, mounts the copilot for artisans only, updates script cache versions, and adds server-side OpenAI endpoints.
4. In Render, set `OPENAI_API_KEY` as a server environment variable. Never put the secret in browser code, the ZIP, or Git. Optional model overrides are `KALASUTRA_REALTIME_MODEL`, `KALASUTRA_AI_MODEL`, `KALASUTRA_TRANSCRIBE_MODEL`, and `KALASUTRA_TTS_MODEL`.
5. Deploy the existing V6 service and allow it to restart after the environment variable is saved.
6. Open the deployed app over HTTPS, sign in as an artisan, allow microphone access, and use **Start Talking**. Speak naturally, for example “Mera naya product add karna hai.”
7. Verify that Add Product opens, the compact copilot stays available, voice details update only the fields the artisan stated, the existing photo/making-proof controls remain usable, and the app summarizes the current draft and asks before submitting it for verification.
8. Repeat with the language selector and Buyer account. Buyer screens and navigation must remain the V6 experience.

## Safety and behavior

- The OpenAI key is read only from the server environment.
- The existing Add Product form and verification route remain authoritative.
- The copilot does not auto-submit. A spoken confirmation is required after the AI has asked for it; confirmation expires after two minutes and resets when leaving Add Product.
- Product content is grounded in the artisan's stated information. Missing required photo/story/price/making proof is requested by the existing form flow.
- If Realtime is unavailable, audio capture/transcription, the existing AI response route and OpenAI TTS are used where supported. Browser speech recognition/synthesis are last-resort fallbacks and are not equivalent to the natural Realtime voice.

## Verification performed for this package

- `node --check` passed for `app.js`, `karigar-warm-welcome-v7.js`, `server/ai-routes.js`, and `server/server.js`.
- `git diff --check` passed.
- Local HTTP smoke checks returned 200 for `/` and the copilot script; invalid empty transcription and product-assist requests returned the expected 400 validation responses.
- The live OpenAI conversation, microphone permission, spoken output, iOS Safari behavior, and full camera-to-verification flow were not exercised here. Complete those checks against the deployed Render service using a real device/browser before treating the spoken flow as accepted.

The ZIP deliberately excludes the full V6 project, database files, unrelated assets, and secrets.
